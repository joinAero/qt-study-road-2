#include "wall.h"

Wall::Wall()
{
}
